<!DOCTYPE HTML>
<html>
<head>
<title>PMB UNIDA GONTOR</title>
<!--css-->
  
  <!-- Bootstrap -->
    <link href="../../../ami/bootstrap.min.css" rel="stylesheet">
    <link href="../../../ami/bootstrap-datepicker.css" rel="stylesheet">
    <link href="../../../ami/style1.css" rel="stylesheet">
    <link href="../../../ami/style2.css" rel="stylesheet">
    <link href="../../../ami/style3.css" rel="stylesheet">

    <link href="../../../css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
    <link href="../../../css/style.css" rel="stylesheet" type="text/css" media="all" />
  <style>
    .content {
      margin-top: 50px;
    }
    .a{
      position: : center;
    }
  </style> 
</head>

<body> 
<!--header-->
    
      <div class="header-top">
        <div class="container">
           <div class="top-left">
            <a href="#">&nbsp;&nbsp;&nbsp;<img src="../../../assets/images/logo.png" style="width:250px"></a>
          </div>
          <div class="top-right">
          <br>
          <ul>
            <li><a href="../cari/index.php">Login</a></li>
            
            <li><a href="create.php"> Registration </a></li>
          </ul>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
      
    <!--header-->
<br><br>
<h1 align="center">Data Gambar di upload</h1><hr>
<h1 align="center" ><a href="form.php" >Tambah Gambar</a></h1><br><br>
<h1 align="center"><a href="profile.php">Lihat Gambar</a></h1><br><br>


</table>
</body>
</html>
