
<!DOCTYPE HTML>
<html>
<head>
  <title>PMB UNIDA GONTOR</title>
  <!--css-->
  <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
  <link href="../../css/style.css" rel="stylesheet" type="text/css" media="all" />
  
  <!--css-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  
  <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
  <script src="js/jquery.min.js"></script>
  <link href='//fonts.googleapis.com/css?family=Cagliostro' rel='stylesheet' type='text/css'>
  <link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>

  <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">
  <link href="http://fonts.googleapis.com/css?family=Allerta+Stencil:400,700,900:normal" rel="stylesheet" type="text/css">
  <!-- Bootstrap Core CSS -->
  <link href="../../bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
  <!-- Plugins CSS -->
  <link href="../../assets/css/normalize.css" type="text/css" rel="stylesheet" />
  <link href="assets/css/animate.css" type="text/css" rel="stylesheet" />
  <!-- Main CSS -->
  <link href="../../assets/css/style.css" type="text/css" rel="stylesheet" />
  <link href="../../assets/css/responsive.css" type="text/css" rel="stylesheet" />
  <!-- icons -->
  <link href="../../assets/css/iline-icons.css" type="text/css" rel="stylesheet" />
  <link href="../../assets/css/magnific-popup.css" type="text/css" rel="stylesheet" />
  <!-- Shortcut icon -->
  <link rel="shortcut icon" href="../../assets/images/favicon.ico" type="image/x-icon"/>

  
  <!--css-->

  <!--search jQuery-->
  <script src="../../js/main.js"></script>
  <!--search jQuery-->
  <script src="js/responsiveslides.min.js"></script>
  <script>
    $(function () {
      $("#slider").responsiveSlides({
        auto: true,
        nav: true,
        speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script>
  <script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
  <script src="js/simpleCart.min.js"></script>
  <script src="js/jstarbox.js"></script>
  <link rel="stylesheet" href="css/jstarbox.css" type="text/css" media="screen" charset="utf-8" />
  <script type="text/javascript">
    jQuery(function() {
      jQuery('.starbox').each(function() {
        var starbox = jQuery(this);
        starbox.starbox({
          average: starbox.attr('data-start-value'),
          changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
          ghosting: starbox.hasClass('ghosting'),
          autoUpdateAverage: starbox.hasClass('autoupdate'),
          buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
          stars: starbox.attr('data-star-count') || 5
        }).bind('starbox-value-changed', function(event, value) {
          if(starbox.hasClass('random')) {
            var val = Math.random();
            starbox.next().text(' '+val);
            return val;
          } 
        })
      });
    });
  </script>

</script>
</head>
<body>
  <!--header-->
  <div class="header">
    <!-- NAVBAR LANJTUAN -->
    <header class="fallone-navbar" data-id="default-navbar">
      <nav class="navbar navbar-default">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li class="active"><a  href="profile.php">Home</a></li>
              <li class="dropdown">
                <li><a  href="biaya.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Biaya</a></li>
                <li><a  href="jadwal.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Jadwal</a></li>
                <li><a  href="info.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;info</a></li>
              </li>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </div><!-- /.container -->
    </nav>
  </header>
  <!-- header -->
  <!-- NAVBAR LANJTUAN -->
  
  
  <!-- MAIN CONTAINER -->
  <div class="main-content">
    
    <!-- BLOG POST BODY SECTION -->

    <section class="pattern-3 no-padding-right">
      <!-- .container -->
      <div class="container">
        <!-- .row -->
        <div class="row">
          <!-- .col-md-12 -->
          <div class="col-md-12">
            <!-- All blog posts -->
            <div>
              <!-- Left part -->
              <div class="col-md-8 blog-main">
                <div class="post-detail sep-bottom-lg">
                  <div class="post-detail-body sep-xs">
                    <h3 class="text-uppercase">PMB UNIDA Gontor</h3>
                    <span class="line-sep-gray"></span>
                    <blockquote >
                      <p style="font-size: 13px" align="justify">
                        <i>
                          Pendaftaran online saat ini telah dibuka <br>
                          Ujian lisan Gelombang I akan dimulai pada 17 April 2018 (Untuk lebih detail, silakan melihat Timing di Halaman ini) <br>
                        </i></p>
                      </blockquote>
                      
                      <h5>Pengumuman  :</h5><hr>
                      <p style="font-size: 13px" align="justify">Mahasiswa Baru Full Timer Jalur Khusus (Alumni Gontor 2018) diharapkan tiba untuk daftar ulang di Kampus Pusat Siman (Putra) atau Kampus Mantingan (Putri) pada tanggal 6-10 Syawwal. 11 Syawwal akan diadakan pengabsenan.</p>
                      <br><br>

                      <h5>PERSYARATAN PENDAFTARAN</h5><hr>
                      <ol type="circle">
                        <li>Menyerahkan fotocopy STTB dan transkip nilai MA/SMU (yang dilegalisir) sebanyak 2 lembar</li>
                        <li>Menyerahkan pas photo ukuran 3×4 dan 4×6 masing-masing sebanyak 4 lembar</li>
                        <li>Menyerahkan Surat Keterangan Catatan Kepolisian SKCK</li>
                        <li>Mengisi formulir pendaftaran</li>
                        <li>Memenuhi ketentuan-ketentuan yang telah ditetapkan pada waktu pendaftaran.</li>
                        <li>Mendaftarkan diri sesuai dengan waktu dan cara yang telah ditentukan</li>
                      </ol> <br><br>
                      <h5>KETERSEDIAAN PROGRAM STUDI</h5><hr>
                      <p style="font-size: 13px" align="justify">Sebagian Program Studi tersedia khusus untuk putra atau putri. Berikut detailnya:</p>
                      <br><br>
                      <h5>PROGRAM S1</h5><hr>
                      <p style="font-size: 13px" align="justify">FAKULTAS TARBIYAH</p>
                      <ol type="circle">
                        <li>Prodi Pendidikan Agama Islam (Putra & Putri)</i>
                          <li>Prodi Pendidikan Bahasa Arab (Putra & Putri)</li>
                        </ol>
                        <p style="font-size: 13px" align="justify">FAKULTAS USHULUDDIN</p>
                        <ol type="circle">
                          <li>Prodi Studi Agama-agama (Putra & Putri)</i>
                            <li>Prodi Aqidah Filsafat (Putra & Putri)</li>
                            <li>Prodi Ilmu Alqur’an dan Tafsir (Putra & Putri)</li>
                          </ol> 
                          <p style="font-size: 13px" align="justify">FAKULTAS SYARIAH</p>
                          <ol type="circle">
                            <li>Prodi Perbandingan Madzhab (Putra & Putri)</i>
                              <li>Prodi Hukum Ekonomi Syariah (Putra & Putri)</li>
                            </ol>
                            <p style="font-size: 13px" align="justify">FAKULTAS EKONOMI DAN MANAJEMEN</p>
                            <ol type="circle">
                              <li>Prodi Ekonomi Islam (Putra & Putri)</i>
                                <li>Prodi Manajemen (Putra & Putri)</li>
                              </ol>
                              <p style="font-size: 13px" align="justify">FAKULTAS HUMANIORA</p>
                              <ol type="circle">
                                <li>Prodi Ilmu Hubungan Internasional (Putra & Putri)</i>
                                  <li>Prodi Ilmu Komunikasi (Putra)</li>
                                </ol>
                                <p style="font-size: 13px" align="justify">FAKULTAS SAINS DAN TEKNOLOGI</p>
                                <ol type="circle">
                                  <li>Prodi Teknik Informatika (Putra)</i>
                                    <li>Prodi Teknologi Industri Pertanian (Putra)</li>
                                    <li>Prodi Agroteknologi (Putra)</li>
                                  </ol>
                                  <p style="font-size: 13px" align="justify">FAKULTAS ILMU KESEHATAN</p>
                                  <ol type="circle">
                                    <li>Prodi Farmasi (Putri)</i>
                                      <li>Prodi Ilmu Gizi (Putri)</li>
                                      <li>Prodi Kesehatan dan Keselamatan Kerja (Program D4) (Putra)</li>
                                    </ol><br><br>
                                    <h5>SELEKSI MASUK</h5><hr>
                                    <p style="font-size: 13px" align="justify">Ada 2 tahap ujian dalam seleksi masuk UNIDA Gontor, yaitu:</p>
                                    <p style="font-size: 13px" align="justify">Tahap Ujian Lisan, materi :</p>
                                    <ol type="circle">
                                      <li>Alqur’an beserta tajwidnya</i>
                                        <li>Ibadah amaliyah dan ibadah qauliyah, terdiri dari praktek shalat, wudhu, tayamum, adzan, iqomah, hafalan surat-surat pendek dalam Al-Quran, doa sehari-hari, doa setelah shalan Sunnah, dll.</li>
                                        <li>Bahasa Arab dan Bahasa Inggris.</li>
                                        <li>Tes Psikologi.</li>
                                      </ol>
                                      <p style="font-size: 13px" align="justify">Tahap Ujian Tulis, materi :</p>
                                      <ol type="circle">
                                        <li>Bahasa Arab dan Bahasa Inggris</i>
                                          <li>Prodi Studi Islam: Dirasah Islamiyah</li>
                                          <li>Prodi Sains: Matematika, Fisika, Kimia dan Biologi.</li>
                                          <li>Prodi Sosial: Pengetahuan umum.</li>
                                        </ol><br><br>
                                        <h5>TATA CARA PENDAFTARAN</h5><hr>
                                        <p style="font-size: 13px" align="justify">PENDAFTARAN LANGSUNG</p>
                                        <ol type="circle">
                                          <li>Pendaftaran dilakukan secara langsung di kampus UNIDA Gontor, tidak melalui surat menyurat atau telepon</i>
                                            <li>Mengisi formulir pendaftaran.</li>
                                            <li>Syarat-syarat pendaftaran dimasukkan kedalam map, Meliputi :</li>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;fotocopy STTB dan transkip nilai MA/SMU (yang dilegalisir) sebanyak 2 lembar</p>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;photo ukuran 3×4 dan 4×6 masing-masing sebanyak 4 lembar.</p><p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Surat Keterangan Catatan Kepolisian (SKCK) </p>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fotocopy Rapot</p>
                                          </ol>
                                          <blockquote >
                                            <p style="font-size: 12px" align="justify">
                                              <i>
                                                Catatan: Untuk Mahasiswa baru Jalur Khusus (Alumni Gontor 2018), Syarat Pendaftaran adalah sebagai berikut:
                                              </i></p>
                                            </blockquote>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Photo ukuran 3×4 dan 4×6 masing-masing sebanyak 4 lembar.</p>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fotocopy akta kelahiran</p><p style="font-size: 11px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fotocopy kartu keluarga</p>
                                            <p style="font-size: 12px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fotocopy surat pengabdian dari Gontor</p><br>
                                            <h5>TATA CARA PENDAFTARAN</h5><hr>
                                            <ol type="circle">
                                              <li>Calon mahasiswa melakukan entry data pengajuan pendaftaran secara online.</i>
                                                <li>Calon mahasiswa mencetak tanda bukti pendaftaran online.</li>
                                                <li>Calon mahasiswa mempersiapkan berkas/persyaratan sesuai dengan ketentuan.</li>
                                                <li>Calon mahasiswa datang ke kampus UNIDA Gontor untuk menyerahkan tanda bukti pengajuan pendaftaran dan kelengkapan berkas.</li>
                                              </ol><br>
                                            </div>  
                                          </div>
                                        </div>
                                        <!-- /Left part -->
                                        <!-- Right part -->
                                        <div class="col-md-4 blog-sidebar">
                                          <!-- Categories List -->
                                          <div class="post-detail">
                                            <div class="post-detail-body sep-xs">
                                              <h3 class="text-primary text-uppercase text-center">Campus Activities</h3>
                                              <ul class="text-capitalize sidebar">
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/1.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">77 TPQ Teachers Candidate Participated in Tahsin al-Qiro’ah Training at UNIDA Gontor</p>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/2.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">“Al-Hambra” Art Appreciation Night</p>
                                                    <i class="text-muted small">September 6, 2017</i>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/3.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">Arabic Language Teaching Department Served as One of the Pioneers of Arabic Linguistic Corpus Project in Indonesia</p>
                                                    <i class="text-muted small">August 30, 2017</i>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/4.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">For the First Time in History, UNIDA Gontor Held Annual Ceremony of Khutbatu-l- ‘Arsy Orientation Week</p>
                                                    <i class="text-muted small">August 30, 2017</i>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/5.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">Hundreds of Students MTsN Ponorogo Followed Usbu’ Arabiy in UNIDA Gontor</p>
                                                    <i class="text-muted small">August 30, 2017</i>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/6.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">Seminar Nasional – Conference of Indonesian Occupational Safety and Health (CIOSH)</p>
                                                    <i class="text-muted small">March 12, 2018</i>
                                                  </a>
                                                </li>
                                                <li>
                                                  <a href="#">
                                                    <span class="post-img">
                                                      <img src="../../blog/7.jpg" alt="" class="img-responsive" />
                                                    </span> 
                                                    <p style="font-size: 12px;">International Festival of Education and Culture (IFEC)</p>
                                                    <i class="text-muted small">August 18, 2016</i>
                                                  </a>
                                                </li>
                                              </ul>
                                            </div>
                                          </div>
                                          <!-- Categories List End -->
                                          
                                          <!-- Archive List End -->
                                        </div>
                                        <!-- /Right part -->
                                      </div>
                                    </div>
                                    <!-- /.col-md-12 -->
                                  </div>
                                  <!-- /.row -->
                                </div>
                                <!-- /.container -->
                              </section>
                              <!-- BLOG POST BODY SECTION END -->
                            </div>
                            <!-- MAIN CONTAINER END -->

                            <!-- Features -->
                            <div class="footer-w3l">
                              <div class="container">
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">EDUCATION</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Islamic Education <br>
                                    - Arabic Language Teaching <br>
                                  </p>
                                </div>
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">USHULUDDIN</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Comparative Study of Religion  <br>
                                    - Aqidah and Islamic Thought <br>
                                    - Al-Qur’an and Tafsir <br>
                                  </p>
                                </div>
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">SHARI’AH</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Comparative School of Law <br>
                                    - Islamic Economic Laws <br>
                                  </p>
                                </div>
                              </div>
                              <div class="container">
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">SCIENCE AND TECHNOLOGY</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Information Technology <br>
                                    - Agro-industrial Technology <br>
                                    - Agro-technology <br>
                                  </p> 
                                </div>
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">HUMANITIES</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - International Relations <br>
                                    - Communication Sciences <br>
                                  </p>
                                </div>
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">HEALTH</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Pharmacy <br>
                                    - Nutrition <br>
                                    - Occupational Safety and Health <br>
                                  </p>
                                </div>
                              </div>
                              <div class="container">
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">ECONOMICS AND MANAGEMENT</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Islamic Economic Laws <br>
                                    - Business Management <br>
                                  </p> 
                                </div>
                                <div class="col-md-4 mar-bottom-md">
                                  
                                  <h2 class="wow fadeInDown text-uppercase"  data-wow-duration=".8s" data-wow-delay=".2s" style="color: white;">POSTGRADUATE</h2>
                                  <span class="line-sep-gray"></span>
                                  <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s" style="color: white;">
                                    - Department of Islamic Theology <br>
                                    - Arabic Language Teaching <br>
                                  </p>
                                </div>
                                
                              </div>
                            </div>
                            <!-- /Features -->
                            <!-- footer -->
                            <div class="copy-section">
                              <div class="container">
                                <div class="copy-left">
                                  <p>&copy;&nbsp;2018 UNIDA Gontor - All rights reserved.</p>
                                </div>
                                <!-- icon media sosial -->
                                <div class="copy-right">
                                  
                                  <div class="social-icon">
                                    <a href="#"><i class="icon" ></i></a>
                                    <a href="#"><i class="icon1"></i></a>
                                    <a href="#"><i class="icon2"></i></a>
                                    <a href="#"><i class="icon3"></i></a>
                                  </div>
                                  
                                </div>
                                
                                <!-- icon media sosial -->
                              </div>
                            </div>
                            
                            <!-- kembali keatas -->
                            <div id="back-to-top" class="back-to-top">
                             <a href="#" class="icon iline2-thin16 no-margin"></a>
                           </div>
                           <!-- kembali keatas -->
                           <!-- footer -->
                           <script src="../../assets/js/libs/jquery-1.11.2.min.js"></script>
                           <script src="../../bootstrap/js/bootstrap.min.js"></script>
                           <script src="../../assets/js/libs/jqBootstrapValidation.js"></script>
                           <script src="../../assets/js/libs/imagesloaded.pkgd.min.js"></script>
                           <script src="../../assets/js/libs/imagesloaded.js"></script>
                           <script src="../../assets/js/libs/jquery.magnific-popup.min.js"></script>
                           <script src="../../assets/js/libs/isotope.pkgd.min.js"></script>
                           <script src="../../assets/js/libs/ParallaxScrolling.js"></script>
                           <script src="../../assets/js/libs/jquery.mailchimp.js"></script>
                           <script src="../../assets/js/libs/wow.min.js"></script>
                           <script src="../../assets/js/libs/jquery.fittext.js"></script>
                           <script src="../../assets/js/libs/jquery.lettering.js"></script>
                           <script src="../../assets/js/libs/jquery.textillate.js"></script>

                           <!-- Main JS -->
                           <script src="../../assets/js/main.js"></script>
                         </body>
                         </html>